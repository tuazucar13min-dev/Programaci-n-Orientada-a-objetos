/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poo_2;
import java.util.Scanner;
/**
 *
 * @author LAB-USR-AREQUIPA
 */
public class POO_2 {

    public static void main(String[] args) {
        Scanner imput = new Scanner ( System.in );
        int cantidad; 
        int Escoge; 
        
        // DESCUENTO
        // compra 6 polos 
        System.out.println( " Escoge un tipo de ropa  ");
        System.out.println (" 1: Polos ");
        System.out.println(" 2: Camisa ");
        System.out.println(" 3: Chompas");
        Escoge= imput.nextInt ();
        System.out.println(" Escoge la canidad ");
        cantidad=imput.nextInt();
        System.out.println( " Escoge " );
        System.out.println( "1: Ropa para hombre" );
        System.out.println( " 2: Ropa para mujer" );
        int ropa=imput.nextInt();
        
        for ( ropa = 1)
        {
            while ( Escoge ) 
            {
                 case 1:
                    
                        System.out.println( "Colores" );
                        System.out.println(" 1: Rojo");
                        System.out.println(" 2: Amarillo ");
                        System.out.println(" 3: Negro ");
                        System.out.println(" 4: Azul ");
                 break ;       
                 case 2 :        
                        
                        System.out.println( "Colores" );
                        System.out.println(" 1: Negro");
                        System.out.println(" 2: Azul");
                 break;
                 case 3:
                        System.out.println( "Colores" );
                        System.out.println(" 1: Rojo  ");
                        System.out.println(" 2: Amarillo ");
                        System.out.println(" 3: Negro");
                break; 
            }
                
                
                
        {
            case 1:
                    
                        System.out.println( "Colores" );
                        System.out.println(" 1: Rojo");
                        System.out.println(" 2: Amarillo ");
                        System.out.println(" 3: Negro ");
                        System.out.println(" 4: Azul ");
 
        }
            
      
           
            
        }
        

        
       
        
    }
}