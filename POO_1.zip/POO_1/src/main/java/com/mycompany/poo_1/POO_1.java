/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poo_1;
import java.util.Scanner;
/**
 *
 * @author LAB-USR-AREQUIPA
 */
public class POO_1 {

    public static void main(String[] args) {
        Scanner imput = new Scanner ( System.in );
        int cantidad; 
        int Escoge; 
        
        
        System.out.println( " Escoge el tipo de ropa  ");
        System.out.println (" 1: Polos ");
        System.out.println(" 2: Camisa ");
        System.out.println(" 3: Chompas");
        System.out.println(" 4: Jin ");
        Escoge= imput.nextInt ();
        


        
    }
}
